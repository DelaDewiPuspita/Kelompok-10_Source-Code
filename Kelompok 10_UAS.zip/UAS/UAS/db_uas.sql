-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 13, 2023 at 01:20 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_uas`
--

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(32) NOT NULL,
  `name` varchar(50) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `address` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `username`, `password`, `name`, `phone`, `address`) VALUES
(1, 'Shinta', 'e72f38e05c82b2fdf4aaba5c106536b3', 'Shinta Amalia Azhara', '087855161077', 'Wisma Tropodo, Waru Sidoarjo'),
(2, 'azhara', 'e72f38e05c82b2fdf4aaba5c106536b3', 'Shinta Amalia Azhara', '087855161077', 'Wisma Tropodo, Waru Sidoarjo'),
(3, 'amalia', '81dc9bdb52d04dc20036dbd8313ed055', 'Shinta Amalia Azhara', '+6287855161077', 'jl raya');

-- --------------------------------------------------------

--
-- Table structure for table `loginadmin`
--

CREATE TABLE `loginadmin` (
  `username` varchar(10) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `loginadmin`
--

INSERT INTO `loginadmin` (`username`, `password`) VALUES
('admin', '464d5b9b1ba558a4c8afb8e4fe1ebd63');

-- --------------------------------------------------------

--
-- Table structure for table `pemesanan`
--

CREATE TABLE `pemesanan` (
  `id` int(11) NOT NULL,
  `tanggal` date DEFAULT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `no_hp` varchar(20) DEFAULT NULL,
  `jenis_tugas` varchar(50) DEFAULT NULL,
  `detail_pesanan` text DEFAULT NULL,
  `metode_pembayaran` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pemesanan`
--

INSERT INTO `pemesanan` (`id`, `tanggal`, `nama`, `email`, `no_hp`, `jenis_tugas`, `detail_pesanan`, `metode_pembayaran`) VALUES
(2, '2023-06-12', 'SHINTA AMALIA AZHARA', 'shintaamaliaazhara@gmail.com', '087855161077', 'ipa11', '', 'cash'),
(3, '2023-06-12', 'dela', 'deladwip@gmail.com', '087855161077', 'b_inggris', '', 'cash'),
(4, '2023-06-13', 'amalia', 'shintaamaliaazhara@gmail.com', '08755161077', 'b_inggris', 'deadline tgl 15 kak', 'transfer'),
(5, '2023-06-13', 'puspita', 'puspita@gmail.com', '08755161077', 'b_inggris', 'deadline tgl 25 kak', 'ewallet'),
(6, '2023-06-13', 'puspita', 'puspita@gmail.com', '08755161077', 'b_inggris', 'deadline tgl 25 kak', 'ewallet'),
(7, '2023-06-13', 'shinta', 'shintaamaliaazhara@gmail.com', '08755161077', 'matematika', 'deadline tgl 15 kak', 'transfer');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pemesanan`
--
ALTER TABLE `pemesanan`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `pemesanan`
--
ALTER TABLE `pemesanan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
